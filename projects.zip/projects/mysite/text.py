# f=lambda x,y:x+y
# print(f(1,2))
# print([1,2]*2)

# def f(a=1,b):
#     pass
# f(2)
def func(list_target):
    for i in range(len(list_target)-2):
        for j in range(i+1,len(list_target)-1):
            if list_target[i] != list_target[j]:
                for n in range(j+1,len(list_target)):
                    if list_target[j] != list_target[n]:
                        if list_target[i] + list_target[j] + list_target[n] == 0:
                            return (list_target[i], list_target[j], list_target[n])
                    else:
                        continue
            else:
                continue
print(func([-1,-1,-2,3,4]))