function createXhr(){
        if (window.XMLHttpRequest){
            return  xhr2 = new XMLHttpRequest();
        }else{
            return xhr2 = new  ActiveXObject('Microsoft.XMLHttpResuest');
        }
        //print xhr
        // console.log(xhr2);
        }