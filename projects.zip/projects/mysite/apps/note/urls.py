from django.conf.urls import url
from .views import *


app_name='note'

urlpatterns = [
    url(r'^$', note_view,name='index'),
    url(r'^add/$', add_view),
    url(r'^mod/(\d+)$', mod_view),
    url(r'^del/(\d+)$', del_view),
    url(r'^upload/$', upload_view)
]