import os
from django.core.paginator import Paginator
from django.shortcuts import render, redirect,HttpResponseRedirect,HttpResponse
from users.models import User
from .models import Note
from django.shortcuts import reverse
from mysite.settings import MEDIA_ROOT
from django.contrib.auth.models import User
# from mysite.mysite.settings import STATICFILES_DIRS
# Create your views here.
# 登录检测【装饰器】 <-- 闭包
# def check_login(fn):
#     def func(request, *args, **kwargs):
#         if not hasattr(request, 'session'):
#             return HttpResponseRedirect('/user/login')
#         if 'user' not in request.session:
#             return HttpResponseRedirect('/user/login')
#         return fn(request, *args, **kwargs)
#     return func

def check_login(fu):
    def func(request,*args,**kwargs):
        if not hasattr(request,'session'):
            return HttpResponseRedirect('/user/login')
        if 'user' not in request.session:
            return HttpResponseRedirect('/user/login')
        return fu(request,*args,**kwargs)
    return func

def note_view(request):
#首页
    uname=request.session['user']
    # uname=request.session['user']['username']
    auser=User.objects.get(username=uname)
    notes=auser.note_set.all()
    # return render(request,'note/list.html',locals())
    # 1、传入对象列表与每页显示的数据条数，返回分页对象
    paginator = Paginator(notes, 5)

    # 分页对象的属性
    print('对象总数：', paginator.count)
    print('总页数：', paginator.num_pages)
    print('当前的页码数：', paginator.page_range)
    print('每页数据个数：', paginator.per_page)
    # print('page方法：', paginator.page(2))

    # 2、获取url中的page的值【知晓当前是第几页】
    cur_page = request.GET.get('page', 1)

    # 3、获取的page值转换为成为整形
    cur_page = int(cur_page)

    # 4、生成指定页的page对象
    page = paginator.page(cur_page)
    # print('当前页的对象列表：', page.object_list)
    # print('当前页的对象列表：', page)
    # print('当前页的页码：', page.number)
    return render(request, 'note/list_page.html', locals())


@check_login
def add_view(request):
    if request.method=='GET':
        return render(request, 'note/add_note.html')
    elif request.method == 'POST':
        title=request.POST.get('title','')
        content=request.POST.get('content','')
        user_name=request.session['user']
        # user_name=request.session['user']
        auser=User.objects.get(username=user_name)
        anote=Note(user=auser)
        anote.title=title
        anote.content=content
        anote.save()
        # return render(request, 'note/list_page.html', locals())
        return HttpResponseRedirect('/note/')
@check_login
def mod_view(request, id):
    user_name = request.session['user']
    auser = User.objects.get(username=user_name)
    anote = Note.objects.get(user=auser, id=id)
    if request.method == 'GET':
        return render(request, 'note/mod_note.html', locals())
    elif request.method == 'POST':
        # 获取前端数据
        title = request.POST.get('title', '')
        content = request.POST.get('content', '')
        anote.title = title
        anote.content = content
        anote.save()
        return redirect(reverse('note:index'))
        # return HttpResponseRedirect('/note/')

@check_login
def del_view(request,id):
    user_name = request.session['user']
    auser = User.objects.get(username=user_name)
    anote = Note.objects.get(user=auser, id=id)
    anote.delete()
    # return redirect(reverse('note:index'))
    return HttpResponseRedirect('/note/')

def upload_view(request):
    if request.method == 'GET':
        return render(request,'note/upload.html')
    elif request.method=='POST':
        # files = request.FILES['myfile']
        # # print('文件的名称：', files.name)
        # # print('文件的字节流数据：', files.file)
        #
        # # 保存下来[文件的路径、数据]
        # file_path = os.path.join(MEDIA_ROOT, files.name)
        # print('文件的路径：', file_path)
        # with open(file_path, 'wb') as f:
        #     file_data = files.file.read()
        #     f.write(file_data)
        #     return HttpResponse('文件上传成功')
        files=request.FILES['myfile']
        files_name=request.POST.get('fname','')
        if  files_name:
            files.name=files_name+'.jpg'
        file_path=os.path.join(MEDIA_ROOT,files.name)
        with open(file_path,'wb+') as f:
            file_data=files.file.read()
            f.write(file_data)
            return HttpResponse("上传完成")
