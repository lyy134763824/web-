from django.db import models
# from users.models import User
# Create your models here.
from django.contrib.auth.models import User
class Note(models.Model):
    title = models.CharField('标题', max_length=100)
    content = models.TextField('内容')
    create_time = models.DateTimeField('创建时间', auto_now_add=True)
    mod_time = models.DateTimeField('修改时间', auto_now=True)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    def __str__(self):
        return self.title
    class Meta:
        db_table = 'note_db'
        verbose_name='笔记表'
        verbose_name_plural=verbose_name
