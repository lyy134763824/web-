from django.shortcuts import render, redirect
from django.http import HttpResponse,HttpResponseRedirect,Http404
from django.urls import reverse
# from mysite.mysite.settings import STATICFILES_DIRS
import os

# from django import  forms
from . import forms
from .models import *
from django.contrib.auth import models

# def register_view(request):
#     if request.method=='GET':
#         return render(request,'users/register.html')
#     elif request.method=='POST':
#         name=request.POST.get("uname",'')
#         pwd=request.POST.get('pwd','')
#         pwd2=request.POST.get('pwd2','')
#         print(name,pwd2,pwd)
#         if not name or len(name)<6:
#             uname_error='用户名错误'
#             return render(request, 'users/register.html',locals())
#         elif not pwd and not pwd2:
#         # elif any():
#             pwd_error='密码错误'
#             return render(request, 'users/register.html', locals())
#         elif pwd!=pwd2:
#             pwd_error2 = '密码bu一致'
#             return render(request, 'users/register.html', locals())
#
#         try :
#             models.User.objects.get(username=name)
#             uname_error='用户名重复'
#             return render(request, 'users/register.html', locals())
#         except:
#             # User.objects.create(username=name,password=pwd)
#             # user=models.User.objects.create_superuser(username=name,password=pwd,email='')
#             user=models.User.objects.create_user(username=name,password=pwd,email='')
#             # user=User.objects.create_superuser(username=name,password=pwd,email='')
#             # resp=HttpResponse('注册成功')
#             # resp=redirect(reverse('user:login'))
#             # resp=HttpResponseRedirect("/user/login/")
#             resp=HttpResponseRedirect("/user/login/")
#             resp.set_cookie('uname',name)
#             user.save()
#             return resp

def register_view(request):
    if request.method == 'GET':
        return render(request,'users/register.html')

def register_uname(request):
    if request.method == 'GET':
        uname = request.GET.get('uname','')
        if not uname:
            return HttpResponse('0')
        elif len(uname) < 6:
            return HttpResponse('1')
        try:
            user = models.User.objects.filter(username=uname)
            if user:
                return HttpResponse('2')
            else:
                return HttpResponse('3',locals())
        except Exception as e:
            print(e)
            return HttpResponse('4')
def register_pwd(request):
    if request.method == 'GET':
        pwd = request.GET.get('pwd','')
        if not pwd:
            return HttpResponse('0')
        else:
            return HttpResponse('1',locals())
def register_pwd2(request):
    if request.method == 'GET':
        pwd=request.GET.get('pwd','')
        pwd2 = request.GET.get('pwd2','')
        if not pwd or not pwd2:
            return HttpResponse('0')
        elif pwd != pwd2:
            return HttpResponse('1')
        else:
            return HttpResponse('2',locals())
def register_email(request):
    if request.method == 'GET':
        email=request.GET.get('email','')
        if not email:
            return HttpResponse('0')
        elif '@' not in email:
            return HttpResponse('1')
        else:
            return HttpResponse('2',locals())
def register_server(request):
    if request.method =='POST':
        uname = request.POST.get('uname','')
        pwd = request.POST.get('pwd','')
        pwd2 = request.POST.get('pwd2','')
        email = request.POST.get('email','')
        if not uname:
            return HttpResponse('0')
        elif not pwd or not pwd2:
            return HttpResponse('1')
        elif not email:
            return HttpResponse('2')
        else:
            try:
                user = models.User.objects.create_user(username=uname, password=pwd, email=email)
                user.save()
                resp = HttpResponse('3')
                resp.set_cookie('uname', uname)
                return resp
            except:
                return HttpResponse('error')

def sess_view(request):
    # 保存session
    # request.session['user']='tedu'
    # return HttpResponse('ok')
    # value=request.session['user']
    # value=request.session.get('user','hh')
    # print(value)

    # 删除
    # del request.session['user']
    print(request.session)
    return HttpResponse('ok')

def login_view(request):
# 登录逻辑
    if request.method=='GET':
        # 判断之前又没登录
        if 'user' in request.session:
            return HttpResponseRedirect('/')
        else:
            if 'uname' in request.COOKIES:
                uName = request.COOKIES.get('uname', '')
                request.session['user']=uName
                return HttpResponseRedirect('/')
            else:
                return render(request,'users/login.html',locals())
    elif request.method=='POST':
        uName = request.POST.get("uname", '')
        pwd = request.POST.get('upwd', '')
        remb = request.POST.get('remb', '')
        print(uName, pwd, remb)
        if not uName :
            uname_error='用户名为空'
            return render(request, 'users/login.html',locals())
        if not pwd :
            upwd_error='密码为空'
            return render(request, 'users/login.html',locals())
        if pwd and uName:
            try :
                # auser=models.User.objects.get(username=uName,password=pwd)
                # auser=User.objects.get(username=uName)
                # print(auser.id)
                # request.session['user']={
                #     'username':uName,
                #     'id':auser.id
                # }
                 user = models.User.objects.get(username=uName)
                 print(user.password)
                 if user.check_password(pwd):
                    resp = HttpResponseRedirect('/')
                    request.session['user']=uName
                    # resp=HttpResponseRedirect('/')
                    print('准备')
                    if remb == 'on':
                        resp.set_cookie('uname',uName)
                    # pass
                    return resp
                 else:
                     error_msg = '用户名或密码错误'
                     return render(request, 'users/login.html', locals())
            except:
                upwd_error='用户名或者密码错误'
                # User.objects.create(username=name,password=pwd)
                # resp=HttpResponse('注册成功')
                # resp.set_cookie('uname',name)
                return render(request,'users/login.html',locals())
        else:
            error_msg = '用户名或密码不能为空'
            return render(request, 'users/login.html', locals())

def logout_view(request):
        if 'user' in request.session:
            del request.session['user']
            request.session.flush()  # 清除缓存
        return HttpResponseRedirect('/')

def text_view(request):
    print(request.META['REMOTE_ADDR'])
    return HttpResponse('请球成功')

def reg2_view(request):
    '''方法1'''
    # myform=forms.MyForms()
    # html=myform.as_p()
    # return HttpResponse(html)
    '''  方法2 '''
    myform = forms.MyForms()
    return render(request, 'users/forms.html', locals())

def login2_view(request):
    if request.method=='GET':
        return render(request,'users/login.html',locals())
    if request.method=='POST':
        # name = request.POST.get('uname', '')
        # pwd = request.POST.get('upwd', '')
        # dic = dict(request.POST)
        # return HttpResponse(str(dic))

        myform = forms.LoginFroms(request.POST)
        # 对数据有效性验证（要传递的数据是否符合要求）
        if myform.is_valid():
            # 将无效数据清除（token）
            dic = myform.cleaned_data
            print(dic['uname'], dic['upwd'])
            return HttpResponse(str(dic))
        #

#文件上传
# def upload_file(request):
#     if request.method=='GET':
#         return render(request,'note/upload.html')
#     elif request.method=='POST':
#         files=request.FILES['myfile']
#         # print('文件名成',files.name)
#         # print('文件字节流数据',files.file)
# #         保存地址
#         file_path=os.path.join(STATICFILES_DIRS,files.name)
#         with open(file_path,'w+') as f:
#             pass

def del_view(request):
    #删除用户(登录才有）
    uname= request.COOKIES.get('uname','')
    user=models.User.objects.get(username=uname)
    user.is_active=0
    user.save()
    del request.session['user']
    request.session.flush()
    resp=HttpResponseRedirect('/')
    resp.delete_cookie('uname')
    return  resp


def modpasswd(request):
    uName = request.COOKIES.get('uname', '')
    if request.method=='GET':
        return render(request,'users/modpwd.html',locals())
    elif request.method=='POST':
        old_password = request.POST.get('old_pwd', '')
        new_password = request.POST.get('new_pwd', '')

        # 检查旧密码是否正确
        try:
            user = models.User.objects.get(username=uName)
            # print(old_password, user.password)
            if user.check_password(old_password):
                user.set_password(new_password)
                user.save()
                print(new_password)
                return HttpResponseRedirect('/user/login/')
            else:  # 原密码错误
                error_msg = '原密码错误'
                return render(request, 'users/modpwd.html', locals())
        except:
            error_msg = '用户名错误'
            return render(request, 'users/modpwd.html', locals())



def four_view(request):
    raise Http404
    # return render(request,'users/404.html')


def page_view(request,n):
    n=n
    return render(request,'users/page1.html',locals())
def page_view1(request):
    return render(request,'users/page.html')