from django.db import models
from django.http import HttpResponse, Http404
# Create your models here.
class User(models.Model):
    username = models.CharField("用户名", max_length=30, unique=True)
    password = models.CharField("密码", max_length=30)

    def __str__(self):
        return self.username

    class Meta:
        db_table='user_db'