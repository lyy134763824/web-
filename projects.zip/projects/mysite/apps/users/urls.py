from django.conf.urls import url

from .views import *

app_name = 'user'

urlpatterns = [
    url(r'^register/$',register_view,name='register'),
    url(r'^register_uname/$',register_uname,name='register_uname'),
    url(r'^register_pwd/$',register_pwd,name='register_pwd'),
    url(r'^register_pwd2/$',register_pwd2,name='register_pwd2'),
    url(r'^register_email/$',register_email,name='register_email'),
    url(r'^register_server/$',register_server,name='register_server'),

    url(r'^page(\d+)$',page_view,name='pagen'),
    url(r'^$',page_view1,name='page'),
    # url(r'^sess/$',sess_view)
    url(r'^login/$',login_view,name='login'),
    url(r'^logout/$', logout_view),
    url(r'^text/$', text_view),
    url(r'^reg2/$', reg2_view),
    # url(r'^reg3/$', reg2_view),
    url(r'^del/$', del_view),
    url(r'^modpwd/$',modpasswd),
    url(r'^abc$',four_view),
]