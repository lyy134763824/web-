from django import forms

class MyForms(forms.Form):
    name=forms.CharField(label='用户名',max_length=30,initial='lyy')
    pwd1=forms.CharField(label='密码1',max_length=30,required=False,widget=forms.PasswordInput)
    # pwd2=forms.CharField('密码2',max_length=30)
    # pwd2=forms.CharField(max_length=30,label='密码2')
    email=forms.EmailField(label='邮箱')



class LoginForms(forms.Form):
    uname=forms.CharField(max_length=20,label='用户名')
    upwd=forms.CharField(max_length=20,label='密码',widget=forms.PasswordInput)










