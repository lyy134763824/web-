from django.conf.urls import url
from .views import *
app_name='index'
urlpatterns = [
    url(r'^$', index_view),
    url(r'^oto/$',OneToOne),
    url(r'^otm/$',OneToMany),
    url(r'^mtm/$',ManyToMany),
    url(r'^cook/$',cook_view),

]