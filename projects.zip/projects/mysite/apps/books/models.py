from django.db import models

class Users(models.Model):
    CHIOCE=(
        (0,'女'),
        (1,'男')
    )
    uname=models.CharField(max_length=30,unique=True,verbose_name='用户名')
    age=models.IntegerField(default=18,verbose_name='年龄')
    sex=models.IntegerField(choices=CHIOCE,default=1,verbose_name='性别')
    def __str__(self):
        return self.uname
    class Meta:
        db_table='users'
        verbose_name='用户表'
        verbose_name_plural=verbose_name
class IdentCode(models.Model):
    code = models.IntegerField(verbose_name='身分号')
    ident=models.CharField(max_length=30, verbose_name='职业',default='教师')
    user = models.OneToOneField(Users,verbose_name='Uid',on_delete=models.CASCADE)
    class Meta:
        db_table='indentcodes'
        verbose_name = '身份表'
        verbose_name_plural = verbose_name
class Order(models.Model):
    CHIOCE=(
        (0,'成交'),
        (1,'失败')
    )
    code=models.IntegerField(unique=True,verbose_name='订单号')
    times=models.DateTimeField(auto_now=True,verbose_name='订单时间')
    status=models.IntegerField(choices=CHIOCE,default=1,verbose_name='状态')
    user=models.ForeignKey(Users,verbose_name='Urd',on_delete=models.CASCADE)

    class Meta:
        db_table='orders'
        verbose_name='订单表'
        verbose_name_plural=verbose_name
#作假表
class Author(models.Model):
    CHIOCE=(
        (0, '女'),
        (1, '男')
    )
    age = models.IntegerField(verbose_name='年龄',default=30)
    sex=models.SmallIntegerField(choices=CHIOCE,default=1,verbose_name='性别')
    name = models.CharField(max_length=30, verbose_name='作家名')
    user = models.OneToOneField(Users, verbose_name='Uid',on_delete=models.CASCADE)
    class Meta:
        db_table='author'
        verbose_name='作家表'
        verbose_name_plural=verbose_name
    def __str__(self):
        return self.name
class Book(models.Model):
    title = models.CharField(max_length=30, verbose_name='书名')
    pub = models.CharField(max_length=50, default='北京大学出版社', verbose_name='出版社')
    price=models.FloatField(default=100, verbose_name='市场价')
    times=models.DateField(verbose_name='出版日期', default='2020-06-08' )
    author=models.ManyToManyField(Author,verbose_name='aid')
    # def __str__(self):
    #     return self.title
    class Meta:
        db_table = 'book'
        verbose_name = '书籍表'
        verbose_name_plural = verbose_name












