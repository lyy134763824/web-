from django.contrib import admin
from .models import *

class BookMenger(admin.ModelAdmin):
    list_display = ['title', 'pub','price','times']
    list_filter = ['title']
    search_fields = ['title']
class IdentCodeMenger(admin.ModelAdmin):
    list_display = ['code', 'ident','user']
    list_filter = ['user']
    search_fields = ['ident']
class UsersMenger(admin.ModelAdmin):
    list_display = ['uname', 'age','sex']
    list_filter = ['age']
    search_fields = ['uname']
class OrderMenger(admin.ModelAdmin):
    list_display = ['code','times','user']
class AuthorMenger(admin.ModelAdmin):
    list_display = ['name', 'age', 'sex']




admin.site.register(Book, BookMenger)
admin.site.register(Users, UsersMenger)
admin.site.register(IdentCode, IdentCodeMenger)
admin.site.register(Order, OrderMenger)
admin.site.register(Author, AuthorMenger)
