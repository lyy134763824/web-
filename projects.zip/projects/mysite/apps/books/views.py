from django.shortcuts import render
from django.http import HttpResponse
from .models import *

def index_view(request):
    res = Book.objects.filter(pub='北京大学出版社')
    for item in res:
        print(item.title, item.pub)
    return HttpResponse('books首页')
def OneToOne(request):
    # user1=Users.objects.get(uname='小李')
    # IdentCode.objects.create(
    #     code=2,
    #     ident='cxy',
    #     user=user1
    # )
    ident=IdentCode.objects.get(ident='cxy')
    print(f'{ident.code}对应的是·{ident.user}')

    user1=Users.objects.get(uname='小李')
    print(f'{user1.uname}对应的是·{user1.identcode.ident}')
    return HttpResponse("OK")
def OneToMany(request):
    #从user到order 1 对`多
    # user1=Users.objects.get(uname='小张')
    # order_times=user1.order_set.all()
    # for item in order_times:
    #     print(f'小张订单号为{item.code},状态为{item.status}')
    #  1 对 1
    order=Order.objects.get(id='1')
    print(f'{order.code}对应的是·{order.user}')

    return HttpResponse("orderok")


def ManyToMany(request):
    #book增加数据
    # auth1=Author.objects.create(name='小臂',age='15')
    # auth2=Author.objects.get(name='小张')
    # book1=auth1.book_set.create(title='python3')
    # auth2.Book_set.add
    # book1=Book.objects.get(id=5)
    # res=book1.author.all()
    # for item in res:
    #     print(item.name,item.age)
    # print('------------------')
    bookes=Book.objects.all()
    for book in bookes:
        auths=book.author.all()
        for auth in auths:
            print(f'{book.title}的作者是{auth.name}')

    print('******************')
    return HttpResponse('mtom  ok')

def cook_view(request):
    res=HttpResponse("ok")
    # res.set_cookie('uname','123',max_age=5)
    res.set_cookie('uname','123')
    value=request.COOKIES.get('uname','')
    if value =='123':
        print('Yes')
    return res



