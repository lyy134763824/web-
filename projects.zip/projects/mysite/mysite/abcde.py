def application(env, start_response):
    start_response('200 OK', [('Content-Type','text/html')])
    return [b"Hello World"] # python3
#
# with open('urls_2.py','a') as f:
#     m=f.mode
#     print(m)
# import re
# a=re.compile('0-9')
# print(a.findall('3 ddd'))

# def my(func):
#     def inner(*args,**kwargs):
#         inner.i +=1
#         # return func(*args,**kwargs)
#     inner.i = 0
#     return inner
# @my
# def text():
#     pass
# text()
# text()
# text()
# print(text.i)
# t = (1,3)
# t[1]=5
# print(t)










